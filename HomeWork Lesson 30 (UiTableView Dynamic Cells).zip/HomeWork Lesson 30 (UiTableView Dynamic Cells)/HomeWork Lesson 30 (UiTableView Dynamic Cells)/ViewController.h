//
//  ViewController.h
//  HomeWork Lesson 30 (UiTableView Dynamic Cells)
//
//  Created by Anton Gorlov on 18.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end


//
//  AGStudent(master level).h
//  HomeWork Lesson 30 (UiTableView Dynamic Cells)
//
//  Created by Anton Gorlov on 19.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGStudent_master_level_ : UITableViewController

@property (strong, nonatomic) NSString* firstName;
@property (strong, nonatomic) NSString* lastName;

@property (assign, nonatomic) NSInteger employeeID; //нумерация студентов

@property (assign, nonatomic) NSInteger highScore; // оценка студента



@end

//
//  ViewController.m
//  HomeWork Lesson 30 (UiTableView Dynamic Cells)
//
//  Created by Anton Gorlov on 18.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGLevelStudent.h"
#import "AGStudent(master level).h"


@interface ViewController ()
//for "pupil" level

@property (assign, nonatomic) CGFloat redColor;
@property (assign, nonatomic) CGFloat greenColor;
@property (assign, nonatomic) CGFloat blueColor;

//for "student" level
@property (assign, nonatomic) NSInteger numberOfRowsInSection;
@property (strong, nonatomic) AGLevelStudent* custom;
@property(strong, nonatomic)NSMutableArray* customArray;

//for "master" level
@property (strong, nonatomic) AGStudent_master_level_*  student;
@property (strong, nonatomic) NSArray* firstNamesArray;
@property (strong, nonatomic) NSArray* lastNameArray;
@property (strong, nonatomic) NSMutableArray* studentsArray;

//for "superman" level
@property (strong, nonatomic) NSArray* termsArray; // название группы (Отличник,хорошист и т.д)
@property (assign, nonatomic) NSInteger numberOfSection;

@property (strong, nonatomic) NSMutableArray* studentsGroupsArray;

@property (strong, nonatomic) NSMutableArray* pupilExcellentArray;
@property (strong, nonatomic) NSMutableArray* pupilGoodArray;
@property (strong, nonatomic) NSMutableArray* pupilBadArray;
@property (strong, nonatomic) NSMutableArray* pupilHeribleArray;

@end

@implementation ViewController

/*
 Вот теперь начинается самое интересное! Нужна практика, много практики.
 
 Ученик.
 
 1. Создайте таблицу которая содержит 1000 разных ячеек.
 2. для каждой ячейки генирируйте радномный цвет.
 3. RGB данные пишите в тексте ячейки, например: RGB(10,20,255)
 4. Также раскрашивайте текст ячейки этим цветом.
 
 
 Студент.
 
 5. Теперь создайте класс, который содержит цвет и нейм.
 6. В viewDidLoad сгенерируйте 1000 объектов такого класса по принципу из ученика
 7. Положите их в массив и отобразите в таблице
 8. В этом случае когда вы будете листать назад вы увидете те же ячейки, что там и были, а не новые рандомные
 
 Мастер.
 
 9. Возвращаемся к студентам. Сгенерируйте 20-30 разных студентов.
 10. В таблице создавайте не дефаулт ячейку а Value1. В этом случае у вас появится еще одна UILabel - detailLabel.
 11. В textLabel пишите имя и фамилию студента, а в detailLabel его средний бал.
 12. Если средний бал низкий - окрашивайте имя студента в красный цвет
 13. Отсортируйте студентов в алфовитном порядке и отобразите в таблице
 
 
 
 Супермен.
 
 14. Средний бал для студентов ставьте рандомно от 2 до 5
 15. После того, как вы сгенерировали 30 студентов вам надо их разбить на группы:
 отличники, хорошисты, троечники и двоечники
 16. Каждая группа это секция с соответствующим названием.
 17. Студенты внутри своих групп должны быть в алфовитном порядке
 18. Отобразите группы студентов с их оценками в таблице.

 
  Mission Impossible!
 
 19. Добавьте к супермену еще одну секцию, в которой вы отобразите 10 моделей цветов из задания Студент.
 20. Помните, это должно быть 2 разных типа ячеек Value1 для студентов и Default для цветов.
*/
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self tableInsets]; //отступы
    
     //Superman level
    self.studentsGroupsArray = [NSMutableArray array];
    self.pupilExcellentArray = [NSMutableArray array];
    self.pupilGoodArray      = [NSMutableArray array];
    self.pupilBadArray       = [NSMutableArray array];
    self.pupilHeribleArray   = [NSMutableArray array];
    
    self.termsArray = [NSArray arrayWithObjects:@"excellent",@"good",@"bad",@"herible", nil];
    
/*
    //student level
    
    self.numberOfRowsInSection = 1000;
    self.customArray = [NSMutableArray array];
    
    for (NSInteger row = 0; row < self.numberOfRowsInSection; row++) {
        self.custom = [[AGLevelStudent alloc]init];
        self.custom.color = [self randomColor];
        self.custom.name = [NSString stringWithFormat:@"Row : number is %ld, color in RGB (%d, %d,%d)",row, (int)(self.redColor * 255.f),(int)(self.greenColor *255.f),(int)(self.blueColor * 255.f)];
        
        [self.customArray addObject:self.custom];
    }
*/
    //master level
   
    self.studentsArray = [NSMutableArray array];
    
        self.firstNamesArray = [NSArray arrayWithObjects:@"Karina",   @"Yulia",     @"Dasha",  @"Katerina",  @"Inna" ,   @"Inga",
                                                         @"Oksana"   ,@"Alina",     @"Sasha",  @"Valentina", @"Anna",    @"Sveta",
                                                         @"Marina",   @"Elizaveta", @"Nastja", @"Arina",     @"Suzanna", @"Janna",
                                                         @"Jana",     @"Ludmila",   @"Irina",  @"Kamila",    @"Alla",    @"Jenia", nil];
    
    
        self.lastNameArray = [NSArray arrayWithObjects: @"Kovalova",  @"Guseva",  @"Titova",   @"Kuzmina",    @"Krilova", @"Sidorova",
                                                        @"Davidova",  @"Blinova", @"Fedorova", @"Kulikova",   @"Popova",  @"Antonova",
                                                        @"Gromova",   @"Fomina",  @"Frolova",  @"Medvedeva",  @"Orlova",  @"Salimonenko",
                                                        @"Berezkina", @"Semzova", @"Zayceva",  @"Sherbakova", @"Ureva",   @"Gorlova", nil];
    
   // self.numberOfRowsInSection = [self.firstNamesArray count];
   
    self.numberOfSection = 4; //Superman level
    
    //create students list "Master and Student Level"
/*
 //create students list "Master and Student Level"
 for (NSInteger student = 0 ; student < self.numberOfRowsInSection; student++) {
 self.student = [[AGStudent_master_level_ alloc]init];
 self.student.employeeID = student;
 self.student.firstName = [self.firstNamesArray objectAtIndex:student];
 self.student.lastName = [self.lastNameArray objectAtIndex:student];
 
 // self.student.highScore = arc4random() % 6; //рендомная оценка от 0 до 5 Оператор % - это остаток от деления двух целых чисел. // "master" level
 
 [self.studentsArray addObject:self.student];
*/
    //create students list "Superman Level"

    for (NSInteger student = 0 ; student < [self.firstNamesArray count]; student++) {
        self.student = [[AGStudent_master_level_ alloc]init];
        self.student.employeeID = student;
        self.student.firstName = [self.firstNamesArray objectAtIndex:student];
        self.student.lastName = [self.lastNameArray objectAtIndex:student];
        self.student.highScore = arc4random() % 4 +2.f; //рендомная оценка от 2 до 5 // "Superman" level
        
        
        switch (self.student.highScore) {
            case 5: // оценка 5
                [self.pupilExcellentArray addObject:self.student];
                break;
                
            case 4:
                [self.pupilGoodArray addObject:self.student];
                break;
            
            case 3:
                [self.pupilBadArray addObject:self.student];
                break;
                
            case 2:
                [self.pupilHeribleArray addObject:self.student];
                break;
                
        }
        
    }
 
    self.studentsGroupsArray = [NSMutableArray arrayWithObjects:        self.pupilExcellentArray,
                                                                        self.pupilGoodArray,
                                                                        self.pupilBadArray,
                                                                        self.pupilHeribleArray,   nil];
                                        
    
    //sort students list
    
    NSSortDescriptor* sortFirstName = [NSSortDescriptor sortDescriptorWithKey:@"firstName" ascending:YES];
    NSSortDescriptor* sortLastName = [NSSortDescriptor sortDescriptorWithKey:@"lastName" ascending:YES];
    [self.studentsArray sortUsingDescriptors:[NSArray arrayWithObjects:sortFirstName,sortLastName, nil]];// сортируем по алфавиту
    
    //Superman level
    
    for (NSMutableArray* studentsGroup in self.studentsGroupsArray) {
        [studentsGroup sortUsingDescriptors:[NSArray arrayWithObjects:sortFirstName,sortLastName, nil]];
    }
}

#pragma mark- Methods


- (void) tableInsets {
    
    UIEdgeInsets inset = UIEdgeInsetsMake(20, 0, 0, 0);
    self.tableView.contentInset = inset;
    self.tableView.scrollIndicatorInsets = inset;
}

- (CGFloat) randomFromZeroToOne {
    
    return (float)(arc4random() % 256) / 255;
    
}

- (UIColor*) randomColor { 
    
    CGFloat r = self.randomFromZeroToOne;
    CGFloat g = self.randomFromZeroToOne;
    CGFloat b = self.randomFromZeroToOne;
    
    self.redColor = r;
    self.greenColor = g;
    self.blueColor = b;
    
    return [UIColor colorWithRed:r green:g blue:b alpha:1.f];
    
    
}


#pragma mark- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
   // NSInteger numberOfSection = 1;
    
   

    return self.numberOfSection;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    //NSString* header = [NSString stringWithFormat:@"RGB colors"];
    
    //NSString* titleForHeader = [NSString stringWithFormat:@"The list has %ld students",self.numberOfRowsInSection];
    
    //Superman level
    
    NSString* titleForHeader = [NSString stringWithFormat:@"The list %@ has %ld students",[self.termsArray objectAtIndex:section],self.numberOfRowsInSection];
    
    return titleForHeader;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
   // NSLog(@"numberOfRowsInSection %ld",section);
    
   // return 1000;
    self.numberOfRowsInSection = [[self.studentsGroupsArray objectAtIndex:section] count];

    return self.numberOfRowsInSection;

}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* indentifier = @"Cell ";

    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    
    if (!cell) {
        // level "Pupil" and "Student" cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:indentifier]; //UITableViewCellStyleValue1 слева и справа текст в ячейке
        
      /*        level "Pupil"
       
        cell.backgroundColor = [self randomColor];
        cell.textLabel.textColor = [self randomColor];
      */
        
    }
    
/*               level student
 
cell.textLabel.text = [NSString stringWithFormat:@" RGB(%1.2f,%1.2f,%1.2f) ", self.redColor, self.greenColor , self.blueColor];
    
  
    
    self.custom = [self.customArray objectAtIndex:indexPath.row];
    cell.textLabel.text = self.custom.name;
    cell.textLabel.font = [UIFont fontWithName:@"San Francisco" size:20];
    cell.backgroundColor = self.custom.color;
    NSLog(@"cellForRowAtIndexPath : {%ld , %ld}",indexPath.section, indexPath.row);
*/
    //level Superman
    
    self.student = [[self.studentsGroupsArray objectAtIndex:indexPath.section ] objectAtIndex:indexPath.row ];
    
    //level master
    
    //self.student = [self.studentsArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%ld. %@ %@",self.student.employeeID, self.student.firstName,self.student.lastName];
    cell.detailTextLabel.text = [NSString stringWithFormat:@" His average score is %ld",self.student.highScore];
    
    UIFont* font = [UIFont fontWithName:@"Palantino" size:14];
    UIColor* textColor = (self.student.highScore < 3) ? ([UIColor redColor]) : ([UIColor blackColor]);
/*
    //или так
    if (self.student.highScore < 3) {
        UIColor* textColor = [UIColor redColor];
        //cell.textLabel.textColor = cell.detailTextLabel.textColor = textColor;
    }else {
    
        UIColor* textColor = [UIColor blackColor];
       // cell.textLabel.textColor = cell.detailTextLabel.textColor = textColor;
    }
*/
    cell.textLabel.font = cell.detailTextLabel.font = font;
    cell.textLabel.textColor = cell.detailTextLabel.textColor = textColor;
    
   
    NSLog(@"cellForRowAtIndexPath: {%ld , %ld}",indexPath.section,indexPath.row);
    
    
    
    
    return cell;
}










- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

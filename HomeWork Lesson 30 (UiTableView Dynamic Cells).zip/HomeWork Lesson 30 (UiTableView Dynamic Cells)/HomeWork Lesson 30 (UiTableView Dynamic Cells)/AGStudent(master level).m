//
//  AGStudent(master level).m
//  HomeWork Lesson 30 (UiTableView Dynamic Cells)
//
//  Created by Anton Gorlov on 19.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGStudent(master level).h"

@interface AGStudent_master_level_ ()

@end

@implementation AGStudent_master_level_

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end

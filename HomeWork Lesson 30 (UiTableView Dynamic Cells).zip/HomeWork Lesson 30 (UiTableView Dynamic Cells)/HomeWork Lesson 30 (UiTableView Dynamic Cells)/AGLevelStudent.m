//
//  AGLevelStudent.m
//  HomeWork Lesson 30 (UiTableView Dynamic Cells)
//
//  Created by Anton Gorlov on 19.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGLevelStudent.h"

@interface AGLevelStudent ()

@end

@implementation AGLevelStudent

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

#pragma mark- Methods

- (id) init {


    self= [super init];
    
    if (self) {
        self.color = [UIColor whiteColor];
        self.name = @"New row";
    }
    return self;
}

- (NSString*) description {

    return [NSString stringWithFormat:@"name = %@", self.name];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  HW_Les__30__UITableView__Dynamic_cellsTests.m
//  HW Les- 30 (UITableView) Dynamic cellsTests
//
//  Created by Anton Gorlov on 25.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface HW_Les__30__UITableView__Dynamic_cellsTests : XCTestCase

@end

@implementation HW_Les__30__UITableView__Dynamic_cellsTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end

//
//  ViewController.m
//  HW Les- 30 (UITableView) Dynamic cells
//
//  Created by Anton Gorlov on 25.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"
#import "AGGroup.h"
#import "AGPlayers.h"

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self statusBarInsets];
    
    self.groupsArray = [NSMutableArray array];
    self.teamsName = [NSMutableArray array];
    
    self.teamsName = [NSArray arrayWithObjects:@"Manchester United first team",@"Manchester United second team", nil];
    
    
    
    for (int i = 0; i < (arc4random()%2 +1.f); i++) {
        
        AGGroup* group = [[AGGroup alloc]init];
        
       
        
        NSMutableArray* array = [NSMutableArray array];
        
        for (int j = 0; j < (arc4random() %1 +11.f); j++) {
            
            [array addObject:[AGPlayers randomStaff]];
        }
        group.footballPlayers = array;
        [self.groupsArray addObject:group];
        
    }
    
    
}


#pragma mark- UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {


    return [self.groupsArray count];
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {

    NSString* titleForHeader = [NSString stringWithFormat:@" %@",[self.teamsName objectAtIndex:section]];
    return titleForHeader;

}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    AGGroup* group = [self.groupsArray objectAtIndex:section];


    return [group.footballPlayers count];
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString* identifier = @"cell";

    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];

    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    
    AGGroup* group = [self.groupsArray objectAtIndex:indexPath.section];
    AGPlayers* players = [group.footballPlayers objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@",players.firstName];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"Skill %1.f",players.averageScore];
    
    
    return cell;
}





- (void) statusBarInsets {

    UIEdgeInsets  inset = UIEdgeInsetsMake(20, 0, 0, 0);
    UIEdgeInsets  separatorInset = UIEdgeInsetsMake(0, 0, 0, 20);
    
    self.tableView.scrollIndicatorInsets = inset;
    self.tableView.contentInset = inset;
    self.tableView.separatorInset = separatorInset;
    

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

//
//  AGPlayers.h
//  HW Les- 30 (UITableView) Dynamic cells
//
//  Created by Anton Gorlov on 25.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGPlayers : NSObject


@property (strong, nonatomic) NSString* firstName;
@property (assign, nonatomic) float averageScore;

+(AGPlayers*) randomStaff;

@end

//
//  AGPlayers.m
//  HW Les- 30 (UITableView) Dynamic cells
//
//  Created by Anton Gorlov on 25.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGPlayers.h"

@implementation AGPlayers


static NSString* firstNames [] = {

    @"1. David De Gea (GK)",
    @"4. Phil Jones",
    @"12. Chris Smalling",
    @"17. Daley Blind",
    @"25. Antonio Valencia",
    @"8. Juan Mata",
    @"18. Ashley Young",
    @"21. Ander Herrera",
    @"31. Bastian Schweinsteiger",
    @"9. Anthony Martial",
    @"10. Wayne Rooney",
    @"11. Adnan Januzaj",
    @"5. Marcos Rojo",
    @"7. Memphis",
    @"16. Michael Carrick",
    @"23. Luke Shaw",
    @"27. Marouane Fellaini",
    @"28. Morgan Schneiderlin",
    @"35. Jesse Lingard",
    @"36. Matteo Darmian",
    @"39. Marcus Rashford",
    @"52. Ro-Shaun Williams",
    @"51. Timothy Fosu-Mensah",
    @"50. Sam Johnstone",
    @"49. Joe Riley",
    @"48. Will Keane",
    @"47. James Weir",
    @"11. Robin Van Perse",
    @"44. Andreas Pereira",
    @"42. Tyler Blackett",
    @"43. Cameron Borthwick-Jackson",
    @"46. Joe Rothwell",
    @"45. Sean Goss",
    @"41. Regan Poole",
    @"38. Axel Tuanzebe",
    @"37. Donald Love",
    @"33. Paddy McNair",
    @"30. Guillermo Varela",
    @"20. Sergio Romero (GK)",
    @"19. James Wilson",

};


static int namesCount = 40;

+(AGPlayers*) randomStaff {
    
    AGPlayers* players = [[AGPlayers alloc]init];
    
    players.firstName = firstNames [arc4random() % namesCount];
    players.averageScore = (float) (arc4random() % 16+70.f);
    
    return players;
}

@end

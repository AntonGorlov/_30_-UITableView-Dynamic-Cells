//
//  ViewController.m
//  UITableView Dynamic Cells (Lesson 30)
//
//  Created by Anton Gorlov on 17.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //отступы от "Status Bar"
    
    UIEdgeInsets inset = UIEdgeInsetsMake(20, 0, 0, 0);
    self.tableView.contentInset = inset;
    self.tableView.scrollIndicatorInsets = inset;

    
    
}

#pragma mark- UITableViewDataSource


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { //кол-во секций
   
    NSLog(@"numberOfSectionsInTableView");

    return [[UIFont familyNames] count]; //кол-во групп у шрифта
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { //кол-во рядов(ячеек) в секции

   NSLog(@"numberOfRowsInSection");
    
    //как узнать сколько рядов во 2-й секции Font-ов ?
    
    NSArray* arrayFonts = [UIFont familyNames];//берем массив со всеми шрифтами

    NSString* stringName = [arrayFonts objectAtIndex:section]; // берем stringName из массива (arrayFonts) ,ту которая находиться по индексу section
    
    NSArray* fontNames = [UIFont fontNamesForFamilyName:stringName]; //возвращаем массив имен шрифтов внутри какой-то группы шрифтов
    
    //return 5;
    return [fontNames count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { //метод ,который напишет на HeaderInSection (КАК В ПЕРД. УРОКЕ !!! ACOUNT INFO,CLIENT INFO)
    
    NSArray* arrayFonts = [UIFont familyNames];//берем массив со всеми шрифтами
    
    NSString* stringName = [arrayFonts objectAtIndex:section];
    
    return stringName; //если не ставить этот метод,то секция будет без названия
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath { //соз ячейки по indexPath
    
    NSLog(@"cellForRowAtIndexPath {%d , %d}",indexPath.section, indexPath.row);
    
    
    static NSString* indentifier = @"Cell";

    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    if (!cell) { //если ячейки нет,то
        
         //мы соз ячейку
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
        
        NSLog(@"cell created");
        
    }else {
        
        NSLog(@"cell reused");
    
    }
  
    //В ячейки (ряды) ставим (Font) шрифт
    
    NSArray* arrayFonts = [UIFont familyNames]; //берем массив со всеми шрифтами
    
    NSString* stringName = [arrayFonts objectAtIndex:indexPath.section]; // номер секции уже сюда приходит indexPath,а не section
    
    NSArray* fontNames = [UIFont fontNamesForFamilyName:stringName]; //возвращаем массив имен шрифтов внутри какой-то группы шрифтов
    
    NSString* fontName = [fontNames objectAtIndex:indexPath.row];// выбираем один Font в массиве fontNames
    
    cell.textLabel.text = fontName; // выводим в симулятор имя шрифта (данные на экран таблицы)
    
    
    UIFont* font = [UIFont fontWithName:fontName size:22]; // соз Font с именем и размером шрифта
    
    cell.textLabel.font = font;
    

    
    
    
    
    

    return cell;
}

















- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
